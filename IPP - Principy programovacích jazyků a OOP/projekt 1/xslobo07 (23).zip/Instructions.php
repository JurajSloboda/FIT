<?php

//objekt pre spracovanie inštrukcií
class Instruction{
    //počítanie volania inštrukcii pre spracovanie prvého riadku
    private $LoadFunctionCalled;

    public $InstCount;

    //ukladanie mena a argumentov inštrukcie
    public $InstName;
    public $InstArgs = array();

    //konštruktor
    public function __construct(){
        $this->InstCount = 0;
    }
    
    //reset argumentov
    public function ResetNameAndArgs(){
        unset($this->InstName);
        $this->InstArgs = [];
    }

    //načítanie inštrukcie
    public function LoadNext(){
        $this->LoadFunctionCalled++;
        $this->ResetNameAndArgs();
        if ( $line = fgets(STDIN) ) {
            if ($line != "\n")
                $this->InstCount++;
        } else if (($line == false) && ($this->LoadFunctionCalled == 1)) {
            fprintf(STDERR, "chýba prvý riadok\n");
            exit(21);
        }
        else{
            return false;
        }
           
        //$line2 = array();
        $line = preg_replace('/\s+/', ' ', $line);
        
        
        //$line2 = $line;
        //$line = array();
        $line = explode ('#',$line);
        if ($line[0] == ''){
            $this->LoadFunctionCalled--;
            $this->LoadNext();
            return true;
        } else {
            $line = $line[0];
        }
        
            //echo $line[0];
            //echo "\n";
            $line = trim($line);
            $items = explode(' ', $line);

            if ($this->LoadFunctionCalled == 1) { 
                if (empty($items)) {
                    //fprintf(STDERR,"dsaddsadsadaas");
                    fprintf(STDERR, "chýba prvý riadok\n");
                    exit(21);
                }
                else {
                    $items[0] = strtoupper($items[0]);
                    if (((count($items) == 1) && ($items[0] == '.IPPCODE20'))) {
                        return true; 
                    } else {
                        //fprintf(STDERR,"dsadaas");
                        fprintf(STDERR, "chýba prvý riadok\n");
                        exit(21);
                    }
                }
            }

            if (empty($items) || $items[0] == "") 
                $this->LoadNext(); 
            else {
                if ($this->CheckSyntax($items)) {
                    return true;
                }
                else {
                    fprintf(STDERR, "Syntax or lexical error!\n");
                    exit(23);
                }
            }
            return true;
        
    }

    //funkcia na kontrolu syntaxe a lexikálky
    //vstupom sú items--- ridok rozdelení podľa medzie do poľa
    private function CheckSyntax($items){
        if (!(count($items) >= 1 && count($items) <= 4)) {
            return false;
        }

        switch ($items[0]){
            // prace s ramci volani instrukci
            case 'MOVE': // var symb
                if (count($items) == 3) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                } else {
                    exit(23);
                }
                break;
            case 'CREATEFRAME': 
                if (count($items) == 1) {
                    $this->InstName = $items[0];
                    return true;
                }else {

                    exit(23);
                }
                break;
            case 'PUSHFRAME':
                if (count($items) == 1) {
                    $this->InstName = $items[0];
                    return true;
                }else {
                    exit(23);
                }
                break;
            case 'POPFRAME':
                if (count($items) == 3) {
                    $this->InstName = $items[0];
                    return true;
                }else {
                    exit(23);
                }
                break;
            case 'DEFVAR': // var
                if (count($items) == 2) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'CALL': // label
                if (count($items) == 2) {
                    $this->InstName = $items[0];
                    if ($this->CheckLabel($items[1])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'RETURN':
                if (count($items) == 1) {
                    $this->InstName = $items[0];
                    return true;
                }else {
                    exit(23);
                }
                break;
            

            //prace s datovym zasobnikem
            case 'PUSHS': //symb
                if (count($items) == 2) {
                    $this->InstName = $items[0];
                    if ($this->CheckSymb($items[1])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'POPS': // var
                if (count($items) == 3) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            

            
            // aritmeticke, relacni, booleovske a konverzni instrukce
            case 'ADD': //var symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'SUB'://var symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'MUL'://var symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'IDIV'://var symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'LT': //var symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'GT'://var symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'EQ'://var symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'AND'://var symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'OR'://var symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'NOT'://var symb
                if (count($items) == 3) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) ){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'INT2CHAR': // var symb
                if (count($items) == 3) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'STRI2INT'://var symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;

            //vstupne-vystupne instrukce
            case 'READ': // var type
                if (count($items) == 3) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckType($items[2])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'WRITE': // symb
                if (count($items) == 2) {
                    $this->InstName = $items[0];
                    if ($this->CheckSymb($items[1])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;

            //prace s retezci
            case 'CONCAT': // var symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'STRLEN':// var symb
                if (count($items) == 3) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'GETCHAR': //var symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'SETCHAR': // var symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;

            // prace s typy
            case 'TYPE': // var symb
                if (count($items) == 3) {
                    $this->InstName = $items[0];
                    if ($this->CheckVar($items[1]) && $this->CheckSymb($items[2])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;

            //instrukce pro rizeni toku
            case 'LABEL': // label
                if (count($items) == 2) {
                    $this->InstName = $items[0];
                    if ($this->CheckLabel($items[1])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'JUMP': // label
                if (count($items) == 2) {
                    $this->InstName = $items[0];
                    if ($this->CheckLabel($items[1])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'JUMPIFEQ': // label symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckLabel($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'JUMPIFNEQ': // label symb symb
                if (count($items) == 4) {
                    $this->InstName = $items[0];
                    if ($this->CheckLabel($items[1]) && $this->CheckSymb($items[2]) && $this->CheckSymb($items[3])){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'EXIT': // symb
                if (count($items) == 2) {
                    $this->InstName = $items[0];
                    if ($this->CheckSymb($items[1]) ){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;

            // ladici instrukce
            case 'DPRINT': // symb
                if (count($items) == 2) {
                    $this->InstName = $items[0];
                    if ( $this->CheckSymb($items[1]) ){
                        return true;
                    } else {
                        exit(23);
                        return false;
                    }
                }else {
                    exit(23);
                }
                break;
            case 'BREAK':
                if (count($items) == 1) {
                    $this->InstName = $items[0];
                    return true;
                }else {
                    exit(23);
                }
                break;
            default:
                exit(22);
                return false;
        }
        return false;
    }


    //kontrola názvu premennej
    private function CheckVar($var){
        if (preg_match('/^(GF|LF|TF)@(_|-|\$|&|%|\*|\!|\?|[a-zA-Z])(_|-|\$|&|%|\*|\!|\?|[a-z]|[A-Z]|[0-9])*$/', $var)) { 
            array_push($this->InstArgs, ['var' => $var]);
            return true;
        }
        else {
            return false;
        }
    }

    //kontrola symb
    private function CheckSymb($var){
        if (preg_match('/^(int|bool|string|nil)@.*$/', $var)) {
            $var = explode('@', $var);
            
            if ($var[0] == 'int') {
                array_push($this->InstArgs, [$var[0] => $var[1]]);
                return true;
            }
            elseif ($var[0] == 'bool') {
                if (preg_match('/^(true|false)$/', $var[1])) {
                    array_push($this->InstArgs, [$var[0] => $var[1]]);
                    return true;
                }
            }
            elseif( $var[0] == 'nil'){
                if (preg_match('/^(nil)$/', $var[1])){
                    array_push($this->InstArgs, [$var[0] => $var[1]]);
                    return true;
                }
            }
            else {
                if (preg_match('/^(\\\\[0-9]{3}|[^\\\\])*$/', $var[1])) { // /^([a-zA-Z\x{0021}\x{0022}\x{0024}-\x{005B}\x{005D}-\x{FFFF}|(\\\\[0-90-90-9])*$/
                    
                    array_push($this->InstArgs, [$var[0] => $var[1]]);
                    return true;
                }
            }
        }
        elseif (preg_match('/^(GF|LF|TF)@.*$/', $var)) {
            return $this->checkVar($var);
        }
        return false;
    }

    //kontrola label
    private function CheckLabel($var){
        if (preg_match('/^(_|-|\$|&|%|\*|\!|\?|[a-zA-Z])(_|-|\$|&|%|\*|\!|\?|[a-z]|[A-Z]|[0-9])*$/', $var)) { 
            array_push($this->InstArgs, ['var' => $var]);
            return true;
        }
        else {
            return false;
        }
    }

    //kontrola typu
    private function CheckType($var){
        if (preg_match('/^(string|int|bool|nil)$/', $var)) { 
            array_push($this->InstArgs, ['var' => $var]);
            return true;
        }
        else {
            return false;
        }
    }
}