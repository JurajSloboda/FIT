<?php
/**
 * autor: Juraj Sloboda
 * Projekt IPP: part1: parse.php
 * februar 2020
 * VUT FIT 
 */

require_once("./Instructions.php");

CheckArgs(); 
$instruction = new Instruction();
$outputxml = new OutputXml();

//načítavanie vstupu a spracovanie po riadku
while ($argCount = $instruction->loadNext()) {
    if (isset($instruction->InstName)) {
        $outputxml->WriteInstructionStart($instruction->InstName); 
        foreach ($instruction->InstArgs as &$arg) {
            foreach ($arg as $type => $value) 
                $outputxml->WriteArgument($type, $value); 
        }
        $outputxml->WriteElementEnd(); 
    }
}
//výpis na výstup
$outputxml->WriteOutput(); 

//funkcia na checknutie argumentov
 function CheckArgs(){
    global $argc;

    $opts = getopt("",["help"]);
    if ($argc == 1){
        return;
    } elseif($argc == 2){
        if( array_key_exists('help', $opts )){
            fprintf(STDERR,"Program pre prevod IPPcode20 na xml");
            exit(0);
        } else {
            fprintf(STDERR,"nesprávne argumenty");
            exit(10);
        } 
    } else {
        fprintf(STDERR,"nesprávny počet argumentov");
        exit(10);
    }
 }

//objekt pre spracovanie XML za pomoci knižnice XMLWriter
class OutputXML{
    private $xml;
    private $InstCounter;
    private $ArgCounter;

    //konštruktor
    public function __construct(){
        $this->InstCounter = 1;
        $this->xml = new XMLWriter();
        $this->xml->openMemory();
        $this->xml->setIndent(1);
        $this->xml->startDocument('1.0','UTF-8');
        $this->xml->startElement('program');
        $this->xml->writeAttribute('language','IPPcode20');

    }

    //napíše začiatok inštrukcie
    public function WriteInstructionStart($opcode) {
        $this->ArgCounter = 1; 
        $this->xml->startElement('instruction'); 
        $this->xml->writeAttribute('order', $this->InstCounter); 
        $this->xml->writeAttribute('opcode', $opcode); 
        $this->InstCounter++; 
    }

    //vypíše argument inštrukcie
    public function WriteArgument($type, $value) {
        $type = strtolower($type);
        $this->xml->startElement('arg'.$this->ArgCounter); 
        $this->xml->writeAttribute('type', $type);
        $this->xml->text($value); 
        $this->xml->endElement(); 
        $this->ArgCounter++; 
    }

    //napíše koniec začatého elementu
    public function WriteElementEnd() {
        $this->xml->endElement();
    }

    //vypíše xml file na výstup
    public function WriteOutput() {
        $this->xml->endDocument();
        echo $this->xml->outputMemory();
    }

}