""" Author: Juraj Sloboda
    IPPcode20 interpret
    April 2020
"""


import sys
import re
import xml.etree.ElementTree as ET
from os import path, _exit
SourceFile = None
InputFile = None


#function for err msgs
def printError(msg, code):
    sys.stderr.write(msg + "\n")
    _exit(code)

#print --help
if len(sys.argv) == 2 and sys.argv[1] == "--help":
    print(f"Some helpfull words")
    sys.exit(0)

# control all arguments 
for each in sys.argv:
    if re.search("^--input=.+$", each):
        InputFile = re.sub("^--input=", "", each, 0)
    elif re.search("^--source=.+$", each):
        SourceFile = re.sub("^--source=", "", each, 0)
    elif each == "--help":
        printError("Wrong use of help", 10)
    elif each != sys.argv[0]:
        printError("Wrong argument", 10)

#print err if theres no input or source file
if not InputFile and not SourceFile:
    printError("No argument for file", 10)


def readFile(filename):
    error = False
    fp = None
    try:
        fp = open(filename, 'r') if filename else sys.stdin
        text = fp.read()
    except:
        error = True
    finally:
        if fp and fp is not sys.stdin:
            fp.close()
    if error:
        printError("wrong src of file", 11)
    return text

srcText = readFile(SourceFile)

Input = sys.stdin
if InputFile:
    fileerr = False
    Input = open(InputFile, 'r')

    if fileerr:
        printError("cant open input file", 11)

#control of xml format
try:
    parsedXml = ET.fromstring(srcText)
except Exception:
    printError("wrong format of xml", 31)

if parsedXml.tag.upper() != "PROGRAM":
    printError("No atribute program", 32)

#control language ippcode20
try:
    if parsedXml.attrib["language"].upper() != "IPPCODE20":
        printError("worng opcode ippcode20", 32)
except Exception:
    printError("not valid atribute language", 32)

try:
    parsedXml[:] = sorted(parsedXml, key=lambda child: (child.tag, int(child.get('order'))))
    for c in parsedXml:
        c[:] = sorted(c, key=lambda child: (child.tag))
except Exception:
    printError("wrong atribute ordedr", 32)



try:
    for each, m in parsedXml.items():
        if each not in ["language", "name", "description"]:
            printError("wrong atributes", 32)
    
    counter = 1
    for i in range(0, len(parsedXml)):
        if parsedXml[i].tag != "instruction":
            printError("wrong tag instruction", 32)

        tmp = parsedXml[i].attrib

        if set(tmp.keys()) != set(['opcode', 'order']):
            printError("wrong atribute in instruction", 32)

        if int(parsedXml[i].get("order")) != counter:
            printError("wrong order", 32)
        counter += 1

        for n in range(0, len(parsedXml[i])):
            k = n + 1
            
            a = parsedXml[i][n].items()
            for each, m in a:
                if each != "type":
                    printError("Onlz atribute tzpe allowed", 32)
                if m not in ["string", "label", "var", "nil", "bool", "int", "type"]:
                    printError("wirng type", 32)

            if f"arg{k}" != parsedXml[i][n].tag:
                printError("unexpected arg counter ", 32)
except Exception:
    printError("....", 32)

class Argument(object):
    def __init__(self, type, value):
        self.type = type
        self.value = value

    def __str__(self):
        return self.type + ":" + self.value


class Instruction(object):
    #constructor
    def __init__(self, opcode):
        self.opcode = opcode
        self.args = []

    def addArg(self, type, value):
        self.args.append(Argument(type, value))

    def __str__(self):
        return self.opcode + " " + " ".join(str(a) for a in self.args)

    def len(self):
        return len(self.args)

instructions = []


def pregMatch(pattern, string):
    return bool(re.match(pattern, string))

#regexes for all tzpes
reg_var = r"^(GF|LF|TF)@(_|-|\$|&|%|\*|\!|\?|[a-zA-Z])(_|-|\$|&|%|\*|\!|\?|[a-z]|[A-Z]|[0-9])*$"
reg_label = r"^(_|-|\$|&|%|\*|\!|\?|[a-zA-Z])(_|-|\$|&|%|\*|\!|\?|[a-z]|[A-Z]|[0-9])*$"
reg_string = r"^(\\\d{3,}|[^\\\s])*$"
reg_int = r"^[+-]?[\d]+$"
reg_nil = r"^nil$"
reg_bool = r"^true|false$"

#check type
def check(type, val):
    types = ["var", "nil", "bool", "int", "string"]
    matchreg = [reg_var, reg_nil, reg_bool, reg_int, reg_string]
    try:
        for i in range(0, len(types)):
            if type == types[i] and pregMatch(matchreg[i], val):
                return True
        return False
    except:
        if val == None and type == "string":
            return True

#check syntax
for i in range(0, len(parsedXml)):
    args = parsedXml[i]
    opCode = parsedXml[i].attrib["opcode"].upper()


    if opCode not in ["DEFVAR", "POPS", "WRITE", "PUSHS", "EXIT", "DPRINT", "CALL", "LABEL", "JUMP", "MOVE", "INT2CHAR", "STRLEN", "TYPE", "READ", "BREAK", "RETURN", "CREATEFRAME", "PUSHFRAME", "POPFRAME", "ADD", "SUB", "MUL", "IDIV", "LT", "AND", "STRI2INT", "CONCAT", "GETCHAR", "SETCHAR", "OR", "NOT", "GT", "EQ", "JUMPIFEQ", "JUMPIFNEQ"]:
        printError("Isnt vlaid instruction", 32)

    if opCode in ["BREAK", "RETURN", "CREATEFRAME", "PUSHFRAME", "POPFRAME"] and len(args) == 0:
        instructions.append(Instruction(opCode))
        continue
    elif opCode in ["DEFVAR", "POPS"] and len(args) == 1:
        arg1Type = args[0].attrib["type"]
        arg1Val = args[0].text
        if arg1Type == "var":
            if pregMatch(reg_var, arg1Val):
                ins = Instruction(opCode)
                ins.addArg(arg1Val, "None")
                instructions.append(ins)
                continue
    elif opCode in ["CALL", "LABEL", "JUMP"] and len(args) == 1:
        arg1Type = args[0].attrib["type"]
        arg1Val = args[0].text
        if arg1Type == "label":
            if pregMatch(reg_label, arg1Val):
                ins = Instruction(opCode)
                ins.addArg(arg1Type, arg1Val)
                instructions.append(ins)
                continue
    elif opCode in ["WRITE", "PUSHS", "EXIT", "DPRINT"] and len(args) == 1:
        arg1Type = args[0].attrib["type"]
        arg1Val = args[0].text
        if check(arg1Type, arg1Val):
            ins = Instruction(opCode)
            ins.addArg(arg1Type, arg1Val)
            instructions.append(ins)
            continue
    elif opCode in ["MOVE", "INT2CHAR", "STRLEN", "TYPE", "NOT"] and len(args) == 2:
        arg1Type = args[0].attrib["type"]
        arg1Val = args[0].text
        arg2Type = args[1].attrib["type"]
        arg2Val = args[1].text
        if arg1Type == "var" and check(arg2Type, arg2Val):
            if pregMatch(reg_var, arg1Val):
                ins = Instruction(opCode)
                if arg1Val == None:
                    arg1Val = ""
                if arg2Val == None:
                    arg2Val = ""
                ins.addArg(arg1Type, arg1Val)
                ins.addArg(arg2Type, arg2Val)
                instructions.append(ins)
                continue
    elif opCode == "READ" and len(args) == 2:
        arg1Type = args[0].attrib["type"]
        arg1Val = args[0].text
        arg2Type = args[1].attrib["type"]
        arg2Val = args[1].text
        if arg1Type == "var" and pregMatch(reg_var, arg1Val):
            if arg2Type == "type" and arg2Val in ["string", "int", "bool"]:
                ins = Instruction(opCode)
                ins.addArg(arg1Type, arg1Val)
                ins.addArg(arg2Type, arg2Val)
                instructions.append(ins)
                continue
    elif opCode in ["ADD", "SUB", "MUL", "IDIV", "LT", "AND", "STRI2INT", "CONCAT", "GETCHAR", "SETCHAR", "OR", "GT", "EQ"] and len(args) == 3:
        arg1Type = args[0].attrib["type"]
        arg1Val = args[0].text
        arg2Type = args[1].attrib["type"]
        arg2Val = args[1].text
        arg3Type = args[2].attrib["type"]
        arg3Val = args[2].text
        if arg1Type == "var" and pregMatch(reg_var, arg1Val):
            if check(arg2Type, arg2Val) and check(arg3Type, arg3Val):
                ins = Instruction(opCode)
                if arg2Val == None:
                    arg2Val = ""
                if arg3Val == None:
                    arg3Val = ""
                ins.addArg(arg1Type, arg1Val)
                ins.addArg(arg2Type, arg2Val)
                ins.addArg(arg3Type, arg3Val)
                instructions.append(ins)
                continue
    elif opCode in ["JUMPIFNEQ", "JUMPIFEQ"] and len(args) == 3:
        arg1Type = args[0].attrib["type"]
        arg1Val = args[0].text
        arg2Type = args[1].attrib["type"]
        arg2Val = args[1].text
        arg3Type = args[2].attrib["type"]
        arg3Val = args[2].text
        if arg1Type == "label" and pregMatch(reg_label, arg1Val):
            if check(arg2Type, arg2Val) and check(arg3Type, arg3Val):
                ins = Instruction(opCode)
                if arg2Val == None:
                    arg2Val = ""
                if arg3Val == None:
                    arg3Val = ""
                ins.addArg(arg1Type, arg1Val)
                ins.addArg(arg2Type, arg2Val)
                ins.addArg(arg3Type, arg3Val)
                instructions.append(ins)
                continue
    printError("Wrong Syntax", 32)

labels = {}
tfPushed = False
frames = { 'LF': [], 'GF': {}, 'TF': {} }
stack = []

for i in range(0, len(instructions)):
    if instructions[i].opcode == "LABEL":
        val = instructions[i].args[0].value
        if val in labels:
            printError(f"Redefinition: {val}", 52)
        labels[val] = i

def storevar(var, value, checkDefined=True):
    if type(value) != type((1,)):
        traceback.print_stack()
        raise Exception()

    varframe, varname = var.split('@')
    frame = None
    if varframe == 'TF':
        if tfPushed:
            printError('Not defined TF frame', 55)
        frame = frames['TF']
    elif varframe == 'LF':
        if not frames['LF']:
            printError('Not defined LF frame', 55)
        frame = frames['LF'][-1]
    else: # GF
        frame = frames['GF']

    if checkDefined and varname not in frame:
        printError('Not defined variable', 54)

    frame[varname] = value

def getvar(var):
    varframe, varname = var.split('@')
    frame = None
    if varframe == 'TF':
        if tfPushed:
            printError('Not defined TF frame', 55)
        frame = frames['TF']
    elif varframe == 'LF':
        if not frames['LF']:
            printError('Not defined LF frame', 55)
        frame = frames['LF'][-1]
    else: 
        frame = frames['GF']

    if varname not in frame:
        printError('not defined variable', 54)

    return frame[varname]

def defvar(var):
    storevar(var, (None, None), False)

def setvar(var, value):
    storevar(var.value, (value.type, value.value))

def writevar(var):
    if var.type == "var":
        value = getvar(var.value)[1]
 
        if value == None:
           printError("non existing variabel", 55)
    else:
        value = var.value
        if value == "nil":
            value = ""
    print(value, end="")
    sys.stdout.flush()

def getint(x):
    value = False
    try:
        xtype, xvalue = getvar(x.value)
        if xtype == "int":
            return int(xvalue)
        value = True
    except:
        printError(f"Variable doesnt exist", 55)
    if value:
        raise NameError

def add(store, arg1, arg2):
    try:
        if arg1.type == "int":
            a = int(arg1.value)
        if arg2.type == "int":
            b = int(arg2.value)
        if arg1.type == "var":
            a = getint(arg1)
        if arg2.type == "var":
            b = getint(arg2)
        value = a + b
        storevar(store.value, ("int", str(value)))
    except ValueError:
        printError("Non valid type", 53)
    except NameError:
        printError("Non valid type", 53)
    except:
        printError("Non existing variable", 54)

def sub(store, arg1, arg2):
    frame, name = store.value.split("@", 1)
    try:
        if arg1.type == "int":
            a = int(arg1.value)
        if arg2.type == "int":
            b = int(arg2.value)
        if arg1.type == "var":
            a = getint(arg1)
        if arg2.type == "var":
            b = getint(arg2)
        value = a - b
        storevar(store.value, ("int", str(value)))
    except ValueError:
        printError("Non valid type", 53)
    except NameError:
        printError("non valid type", 53)
    except:
        printError("non existing variable", 54)

def mul(store, arg1, arg2):
    frame, name = store.value.split("@", 1)
    try:
        if arg1.type == "int":
            a = int(arg1.value)
        if arg2.type == "int":
            b = int(arg2.value)
        if arg1.type == "var":
            a = getint(arg1)
        if arg2.type == "var":
            b = getint(arg2)
        value = a * b
        storevar(store.value, ("int", str(value)))
    except ValueError:
        printError("non valid type", 53)
    except NameError:
        printError("non valid type", 53)
    except:
        printError("non existing variable", 54)

def div(store, arg1, arg2):
    frame, name = store.value.split("@", 1)
    try:
        if arg1.type == "int":
            a = int(arg1.value)
        if arg2.type == "int":
            b = int(arg2.value)
        if arg1.type == "var":
            a = getint(arg1)
        if arg2.type == "var":
            b = getint(arg2)
        value = a // b
        storevar(store.value, ("int", str(value)))
    except ValueError:
        printError("non valid type", 53)
    except NameError:
        printError("non valid type", 53)
    except ZeroDivisionError:
        printError("zero division", 57)
    except:
        printError("non existing variable", 54)

def pushs(arg):
    if arg.type == "var":
        try:
            frame, name = arg.value.split("@", 1)
            typ, val = getvar(arg.value)
            if val == None:
                printError("variable without value", 54)
            stack.append((typ, val))
        except KeyError:
            printError("no frame", 55)
    else:
        stack.append((arg.type, arg.value))

def pops(arg):
    try:
        storevar(arg.type, stack.pop())
    except KeyError:
        printError("not valid frame", 55)
    except Exception as e:
        printError("empty stack", 56)

def eq(store, arg1, arg2):
    try:
        if arg1.type == "var":
            frame, name = arg1.value.split("@", 1)
            a = getvar(arg1.value)
            atype = a[0]
            aval = a[1]
        else:
            atype = arg1.type
            aval = arg1.value

        if arg2.type == "var":
            frame, name = arg2.value.split("@", 1)
            b = getvar(arg2.value)
            btype = b[0]
            bval = b[1]
        else:
            btype = arg2.type
            bval = arg2.value
        
        if atype == btype:
            val = aval == bval
        elif atype == "nil" or btype == "nil":
            val = False
        else:
            raise ZeroDivisionError;
        
        if val:
            val = ("bool", "true")
        else:
            val = ("bool", "false")
        storevar(store.value, val)
    except ZeroDivisionError:
        printError("no compatible type", 53)
    except:
        printError("wrong variables", 55)

def lt(store, arg1, arg2):
    try:
        if arg1.type == "var":
            a = getvar(arg1.value)
            atype = a[0]
            aval = a[1]
        else:
            atype = arg1.type
            aval = arg1.value

        if arg2.type == "var":
            b = getvar(arg2.value)
            btype = b[0]
            bval = b[1]
        else:
            btype = arg2.type
            bval = arg2.value
        
        if atype == btype and atype != "nil":
            val = aval < bval
        elif atype == btype and atype == "bool":
            val = aval > bval
        elif atype == "nil" or btype == "nil":
            raise ZeroDivisionError;
        else:
            printError("not compatible type", 53)
        
        if val:
            val = ("bool", "true")
        else:
            val = ("bool", "false")
        storevar(store.value, val)
    except ZeroDivisionError:
        printError("nil problem compare", 53)
    except:
        printError("wrong frame variables", 55)

def gt(store, arg1, arg2):
    try:
        if arg1.type == "var":
            a = getvar(arg1.value)
            atype = a[0]
            aval = a[1]
        else:
            atype = arg1.type
            aval = arg1.value

        if arg2.type == "var":
            b = getvar(arg2.value)
            btype = b[0]
            bval = b[1]
        else:
            btype = arg2.type
            bval = arg2.value
        
        if atype == btype and atype != "nil":
            val = aval > bval
        elif atype == btype and atype == "bool":
            val = aval < bval
        elif atype == "nil" or btype == "nil":
            raise ZeroDivisionError;
        else:
            printError("no compatible type", 53)
        
        if val:
            val = ("bool", "true")
        else:
            val = ("bool", "false")
        storevar(store.value, val)
    except ZeroDivisionError:
        printError("cant compare", 53)
    except:
        printError("wrong variables in frame", 55)

def booland(store, arg1, arg2):
    try:
        if arg1.type == "var":
            a = getvar(arg1.value)
            atype = a[0]
            aval = a[1]
        else:
            atype = arg1.type
            aval = arg1.value

        if arg2.type == "var":
            b = getvar(arg2.value)
            btype = b[0]
            bval = b[1]
        else:
            btype = arg2.type
            bval = arg2.value

        if atype == btype and atype == "bool":
            if aval == "true":
                aval = True
            else:
                aval = False

            if bval == "true":
                bval = True
            else:
                bval = False
        else:
            raise ZeroDivisionError

        if aval and bval:
            val = ("bool", "true")
        else:
            val = ("bool", "false")

        storevar(store.value, val)

    except ZeroDivisionError:
        printError("wrong type", 53)
    except:
        printError("frame problem", 55)

def boolor(store, arg1, arg2):
    try:
        if arg1.type == "var":
            a = getvar(arg1.value)
            atype = a[0]
            aval = a[1]
        else:
            atype = arg1.type
            aval = arg1.value

        if arg2.type == "var":
            b = getvar(arg2.value)
            btype = b[0]
            bval = b[1]
        else:
            btype = arg2.type
            bval = arg2.value

        if atype == btype and atype == "bool":
            if aval == "true":
                aval = True
            else:
                aval = False

            if bval == "true":
                bval = True
            else:
                bval = False
        else:
            raise ZeroDivisionError

        if aval or bval:
            val = ("bool", "true")
        else:
            val = ("bool", "false")
        storevar(store.value, val)

    except ZeroDivisionError:
        printError("wrong type", 53)
    except:
        printError("frame problems", 55)

def boolnot(store, arg):
    try:
        if arg.type == "var":
            a = getvar(arg.value)
            atype = a[0]
            aval = a[1]
        else:
            atype = arg.type
            aval = arg.value

        if atype != "bool":
            raise ZeroDivisionError

        if aval == "true":
            aval = "false"
        else:
            aval = "true"

        storevar(store.val, val)
    except ZeroDivisionError:
        printError("not a bool type", 53)
    except:
        printError("frame problem", 55)

def inttochar(store, arg):
    try:
        if arg.type == "int":
            val = arg.value
        elif arg.type == "var":
            a = getvar(arg.value)
            if a[0] == "int":
                val = a[1]
            else:
                raise ZeroDivisionError
        else:
            raise ZeroDivisionError
        storevar(store.value, ("string", chr(int(val))))
    except ZeroDivisionError:
        printError("Nekompatibilni typ INT2CHAR", 53)
    except:
        printError("Spatny ramec INT2CHAR", 55)

def stringtoint(store, arg1, arg2):
    try:
        if arg1.type == "string":
            val = arg1.value
        elif arg1.type == "var":
            a = getvar(arg1.value)
            if a[0] == "string":
                val = a[1]
            else:
                raise ZeroDivisionError
        else:
            raise ZeroDivisionError

        if arg2.type == "int":
            idx = arg2.value
        elif arg2.type == "var":
            b = getvar(arg2.value)
            if a[0] == "int":
                idx = a[1]
            else:
                raise ZeroDivisionError
        else:
            raise ZeroDivisionError
        val = ord(val[int(idx)])

        storevar(store.value, val)
    except ZeroDivisionError:
        printError("not compatible type", 53)
    except IndexError:
        printError("out of index", 58)
    except:
        printError("wrong frame", 55)

def concat(store, arg1, arg2):
    try:
        if arg1.type == "string":
            aval = arg1.value
        elif arg1.type == "var":
            a = getvar(arg1.value)
            if a[0] == "string":
                aval = a[1]
            else:
                raise ZeroDivisionError
        else:
            raise ZeroDivisionError

        if arg2.type == "string":
            bval = arg2.value
        elif arg2.type == "var":
            b = getvar(arg2.value)
            if a[0] == "string":
                bval = a[1]
            else:
                raise ZeroDivisionError
        else:
            raise ZeroDivisionError
        
        val = aval + bval
        storevar(store.value, ("int", val))
    except ZeroDivisionError:
        printError("wrong type", 53)
    except:
        printError("frame problem", 55)

def strlen(store, arg):
    try:
        if arg.type == "string":
            val = arg.value
        elif arg.type == "var":
            a = getvar(arg.value)
            if a[0] == "string":
                val = a[1]
            else:
                raise ZeroDivisionError
        else:
            raise ZeroDivisionError

        val = len(val)

        storevar(store.value, ("int", val))
    except ZeroDivisionError:
        printError("not compatible type", 53)
    except:
        printError("frame problem", 55)

def getchar(store, arg1, arg2):
    try:
        if arg1.type == "string":
            val = arg1.value
        elif arg1.type == "var":
            a = getvar(arg1.value)
            if a[0] == "string":
                val = a[1]
            else:
                raise ZeroDivisionError
        else:
            raise ZeroDivisionError

        if arg2.type == "int":
            idx = arg2.value
        elif arg2.type == "var":
            b = getvar(arg2.value)
            if a[0] == "int":
                idx = a[1]
            else:
                raise ZeroDivisionError
        else:
            raise ZeroDivisionError
        if int(idx) < 0:
            raise IndexError

        val = val[int(idx)]
        storevar(store.value, ("string", val))
    except IndexError:
        printError("out of index", 58)
    except ZeroDivisionError:
        printError("not compatible type", 53)
    except:
        printError("frame problem", 55)

def setchar(store, arg1, arg2):
    try:
        if store.type == "string":
            storeval = store.value
        elif store.type == "var":
            #TODO?
            a = getvar(store.value)
            if a[0] == "string":
                storeval = a[1]
            else:
                raise ZeroDivisionError
        else:
            raise ZeroDivisionError

        if arg1.type == "int":
            idx = arg1.value
        elif arg1.type == "var":
            a = getvar(arg1.value)
            if a[0] == "int":
                idx = a[1]
            else:
                raise ZeroDivisionError
        else:
            raise ZeroDivisionError

        if int(idx) < 0:
            raise IndexError

        if arg2.type == "string":
            string = arg2.value
        elif arg2.type == "var":
            a = getvar(arg2.value)
            if a[0] == "string":
                string = a[1]
            else:
                raise ZeroDivisionError
        else:
            raise ZeroDivisionError

        storeval = list(storeval)
        if string == "":
            raise IndexError
        if len(storeval) == 0:
            storeval.append(string[0])
        else:
            storeval[int(idx)] = string[0]
        storeval = "".join(storeval)
        storevar(store.value, ("string", storeval))
    except IndexError:
        printError("out of index", 58)
    except ZeroDivisionError:
        printError("not compatible type", 53)
    except:
        printError("frame problem", 55)

def gettype(store, arg):
    try:
        if arg.type in ["int", "bool", "nil", "string"]:
            typ = arg.type
        elif arg.type == "var":
            a = getvar(arg.value)
            if a[0] in ["int", "bool", "nil", "string"]:
                typ = a[0]
            elif a[0] == None:
                typ = ""

        storevar(store.value, ("string", typ))
    except:
        printError("frame not existing", 55)

def doexit(arg):
    canexit = False
    try:
        if arg.type == "int":
            val = arg.value
        elif arg.type == "var":
            a = getvar(arg.value)
            if a[0] == "int":
                val = a[1]
            else:
                raise ZeroDivisionError
        else:
            raise ZeroDivisionError
        
        val = int(val)
        if not(0 <= val <= 49):
            raise IndexError
        canexit = True
    except ZeroDivisionError:
        printError("not compatible type", 53)
    except IndexError:
        printError("exit out of range", 57)
    except:
        printError("wrong frame", 55)
    if canexit:
        sys.exit(val)

def jumpifeq(label, arg1, arg2):
    try:
        if arg1.type == "var":
            a = getvar(arg1.value)
            atype = a[0]
            aval = a[1]
        else:
            atype = arg1.type
            aval = arg1.value

        if arg2.type == "var":
            b = getvar(arg2.value)
            btype = b[0]
            bval = b[1]
        else:
            btype = arg2.type
            bval = arg2.value

        if atype == btype:
            val = aval == bval
        elif atype == "nil" or btype == "nil":
            raise ZeroDivisionError
        elif atype == None or btype == None:
            raise IndexError
        else:
            raise ZeroDivisionError

        out = all_labels[label.value]
        if val:
            return out
        else:
            return None

    except ZeroDivisionError:
        printError("not compatible type", 53)
    except IndexError:
        printError("not initialized variable", 54)
    except:
        printError("label problem", 52)

def jumpifneq(label, arg1, arg2):
    try:
        if arg1.type == "var":
            a = getvar(arg1.value)
            atype = a[0]
            aval = a[1]
        else:
            atype = arg1.type
            aval = arg1.value

        if arg2.type == "var":
            b = getvar(arg2.value)
            btype = b[0]
            bval = b[1]
        else:
            btype = arg2.type
            bval = arg2.value
        
        if atype == btype:
            val = aval == bval
        elif atype == "nil" or btype == "nil":
            raise ZeroDivisionError
        elif atype == None or btype == None:
            raise IndexError
        else:
            raise ZeroDivisionError

        out = all_labels[label.value]
        if not val:
            return out
        else:
            return None
    except ZeroDivisionError:
        printError("not compatible type", 53)
    except IndexError:
        printError("not initilized dvariaable", 54)
    except:
        printError("label problem", 52)

def doread(store, arg):
    line = input_fh.readline()
    val = None
    if arg.value == "int":
        try:
            storevar(store.value, ("int", str(int(line))))
        except:
            storevar(store.value, ("int", "0"))
    elif arg.value == "bool":
        storevar(store.value, ("bool", "true" if line.lower() == "true" else "false"))
    elif arg.value == "string":
        storevar(store.value, ("string", line[:len(line) - 1]))
    else:
        printError("wrong type", 53)

callstack=[]
instrptr = 0
while 1==1:
    if instrptr < len(instructions): 
        for ins in [instructions[instrptr]]:
            opcode, args = ins.opcode, ins.args
            if opcode == "DEFVAR":
                defvar(args[0].type)
            elif opcode == "MOVE":
                setvar(*args)
            elif opcode == "CREATEFRAME":
                frames["TF"] = {}
                tfPushed = False
            elif opcode == "PUSHFRAME":
                if tfPushed == False:
                    frames["LF"].append(frames["TF"])
                    tfPushed = True
                    frames["TF"] = {}
                else:
                    printError("wrong use of pushframe", 55)
            elif opcode == "POPFRAME":
                if tfPushed == False:
                    printError("wrong use of popframe", 55)
                if len(frames["LF"]) == 0:
                    printError("emptz lf", 55)
                frames["TF"] = frames["LF"].pop()
                tfPushed = False
            elif opcode == "WRITE":
                writevar(args[0])
            elif opcode == "ADD":
                add(*args)
            elif opcode == "SUB":
                sub(*args)
            elif opcode == "MUL":
                mul(*args)
            elif opcode == "IDIV":
                div(*args)
            elif opcode == "PUSHS":
                pushs(*args)
            elif opcode == "POPS":
                pops(*args)
            elif opcode == "EQ":
                eq(*args)
            elif opcode == "LT":
                lt(*args)
            elif opcode == "GT":
                gt(*args)
            elif opcode == "AND":
                booland(*args)
            elif opcode == "OR":
                boolor(*args)
            elif opcode == "NOT":
                boolnot(*args)
            elif opcode == "INT2CHAR":
                inttochar(*args)
            elif opcode == "STRI2INT":
                stringtoint(*args)
            elif opcode == "CONCAT":
                concat(*args)
            elif opcode == "STRLEN":
                strlen(*args)
            elif opcode == "GETCHAR":
                getchar(*args)
            elif opcode == "SETCHAR":
                setchar(*args)
            elif opcode == "TYPE":
                gettype(*args)
            elif opcode == "READ":
                doread(*args)
            elif opcode == "JUMP":
                try:
                    instrptr = all_labels[args[0].value]
                except:
                    printError("non existing label", 52)
            elif opcode == "JUMPIFEQ":
                x = jumpifeq(*args)
                if x:
                    instrptr = x
            elif opcode == "JUMPIFNEQ":
                x = jumpifneq(*args)
                if x:
                    instrptr = x
            elif opcode == "EXIT":
                doexit(args[0])
            elif opcode == "RETURN":
                if callstack:
                    instrptr = callstack.pop()
                else:
                    printError("nothing in callstack", 56)
            elif opcode == "CALL":
                callstack.append(instrptr+1)
                try:
                    instrptr = all_labels[args[0].value]
                except:
                    printError("non existing label", 56)
            instrptr += 1
    else:
        break